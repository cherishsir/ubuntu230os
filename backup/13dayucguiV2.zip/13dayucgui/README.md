###实现ucgui移植的第13天的代码
####ucgui的运行虚拟机里运行没有问题，在实体机上就不行了，还不知道原因 
![ucgui](https://raw.githubusercontent.com/cherishsir/ubuntu230os/master/13dayucgui/qemu.png)
![ucgui](https://raw.githubusercontent.com/cherishsir/ubuntu230os/master/13dayucgui/hpg4.jpg)

