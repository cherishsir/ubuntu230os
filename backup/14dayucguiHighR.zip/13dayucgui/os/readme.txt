运行方式 ：

1：
make lib  编译生成libucgui.a的静态链接库


2：
make done  编译，运行
