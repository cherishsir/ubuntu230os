
#define VRAM 0XA0000
void set_palette(int start,int end, unsigned char *rgb);
void init_palette(void);
