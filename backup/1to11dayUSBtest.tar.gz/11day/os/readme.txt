高速计时器
make && make copy && make run
